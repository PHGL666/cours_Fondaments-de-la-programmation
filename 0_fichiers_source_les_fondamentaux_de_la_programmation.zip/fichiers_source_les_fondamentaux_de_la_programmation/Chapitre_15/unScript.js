function debut() {
    premiereFonction();
};


// fonctions liées
function premiereFonction() {
    secondeFonction();
}
function secondeFonction() {
    troisiemeFonction();
}
function troisiemeFonction() {
    quatriemefonction();
}
function quatriemeFonction() {
    titrePage.innerHTML = "Clic sur le titre !";
}

// récupère le titre
var titrePage = document.getElementById("titre");
// ajout d'un écouteur sur le clicl
titrePage.addEventListener("click", debut);





